﻿// Cristian Faure
// COSC 1320
// 11/14/19
// Exam 2



using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam2
{
    class Program
    {
        static void Main(string[] args)
        {
            List<IManager> Jobs = new List<IManager>();
            List<IHardwareFixer> Job = new List<IHardwareFixer>();
            Jobs.Add(new Doctor());
            Job.Add(new NetworkAdministrator());
            Jobs.Add(new NetworkEngineer());

            
            Console.ReadKey();

        }
    }
}
