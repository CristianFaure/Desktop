﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam2
{
    class NetworkEngineer : Profession, IManager
    {
        public static void SupportNetwork()
        {

        }

        void IManager.Fire()
        {
            Console.WriteLine("We fire bad network engineers");
        }

        void IManager.Hire()
        {
            Console.WriteLine("We hire great new network engineers");
        }
    }
}
