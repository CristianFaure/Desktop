﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam2
{
    class Doctor : Profession, IManager
    {
        public virtual void DoMedicine()
        {

        }

        public void Fire()
        {
            Console.WriteLine("The doctor was fire for malpractice");
        }

        public void Hire()
        {
            Console.WriteLine("The doctor that is specialized in medicine was hire");
        }
    }
}
