﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam2
{
    class Profession
    {
        string name;
        int age;
        string Education;
        public static void GoToWork()
        {

        }
        public static void DoWork()
        {

        }
    }
}
