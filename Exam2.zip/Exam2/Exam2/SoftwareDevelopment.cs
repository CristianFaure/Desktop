﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam2
{
    class SoftwareDevelopment : Profession, IProgrammer
    {
        public static void WriteSourceCode()
        {

        }

        public void WriteCode()
        {
            Console.WriteLine("I Write Code!");
        }
    }
}
