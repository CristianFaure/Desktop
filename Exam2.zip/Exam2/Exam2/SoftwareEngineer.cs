﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam2
{
    class SoftwareEngineer : Profession, IProgrammer, IManager
    {
        public static void Repair()
        {

        }

        public void Fire()
        {
            Console.WriteLine("I fire Workers who are not productive");
        }

        public void Hire()
        {
            Console.WriteLine("We hire skilled Software Engineer!");
        }

        public void WriteCode()
        {
            Console.WriteLine("We Fix Computers!!");
        }
    }
}
